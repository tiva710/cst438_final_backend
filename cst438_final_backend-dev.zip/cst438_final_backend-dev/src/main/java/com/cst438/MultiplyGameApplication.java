package com.cst438;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiplyGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiplyGameApplication.class, args);
	}

}
