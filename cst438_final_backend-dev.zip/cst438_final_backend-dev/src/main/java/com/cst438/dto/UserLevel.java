package com.cst438.dto;

public record UserLevel(String alias, String level) {
}

